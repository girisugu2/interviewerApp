//
//  InterviewCollectionViewCell.swift
//  interviewer
//
//  Created by Giritharan Sugumar on 7/3/17.
//  Copyright © 2017 giritharan. All rights reserved.
//

import UIKit

class InterviewCollectionViewCell: UICollectionViewCell {
    
}
