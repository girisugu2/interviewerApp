//
//  InterViewerViewController.swift
//  interviewer
//
//  Created by Giritharan Sugumar on 6/30/17.
//  Copyright © 2017 giritharan. All rights reserved.
//

import UIKit


protocol InterviewerDelegate : class {
    
    func sendInterviewer(Interviewer:String)
    
}


class InterViewerViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var interviewerTable: UITableView!
    @IBOutlet weak var navigationButton: UIBarButtonItem!
    
    var design = ["Designer","Developer","Testing","Managing","Organising"]
    var interViewerCell = InterviewerTableViewCell()
    var name = ["A", "B", "C", "D", "E", "F", "G", "H", "I"]
    weak var interviewerDelegate:InterviewerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationButton.target = revealViewController()
        navigationButton.action = #selector(SWRevealViewController.revealToggle(_:))
      
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return design.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let identifier = "interviewerCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath) as! InterviewerTableViewCell
        cell.profileName.text = name[indexPath.row]
        return cell
        
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Table selected is \(indexPath.row)")
        let cell = AddRoundsTableViewCell()
        
    //    if cell.interviewerButton.tag == 0 {
   //         self.interviewerDelegate?.sendInterviewer(Interviewer: name[0])
   //     }
        
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let alertController = UIAlertController(title: "Warning", message: "Are you sure?", preferredStyle: .alert)
            
            let deleteAction = UIAlertAction(title: "Delete", style: .destructive, handler: { (action) in
                self.design.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
            })
            alertController.addAction(deleteAction)
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            alertController.addAction(cancelAction)
            
            present(alertController, animated: true, completion: nil)
        }
    }

}

