//
//  RequiredTableViewCell.swift
//  interviewer
//
//  Created by Giritharan Sugumar on 8/6/17.
//  Copyright © 2017 giritharan. All rights reserved.
//

import UIKit

protocol RequiredTblCellDelegate : class {

    func sendNumberOfRound(noOFRounds:Int)
    
}

class RequiredTableViewCell: UITableViewCell , UITextFieldDelegate {
   
    @IBOutlet weak var requiredField: UILabel!
    
    @IBOutlet weak var numberText: UITextField!
    @IBOutlet weak var minusBtn: UIButton!
   
    @IBOutlet weak var plusBtn: UIButton!
//    var numberUserDefault = UserDefaults.standard
    weak var delegate:RequiredTblCellDelegate?
    var checkRound:Bool = false
    
   var number:Int = 0 {
        didSet {
            numberText.text = "\(number)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //requiredField.tag = 1
        number = 0
        
//        if number != 0 {
//            print("Number Present")
//            checkRound = true
//        }
    }
    
    
    
    @IBAction func minusButton(_ sender: Any) {
    
        number -= 1
        
        if number < 0 {
            number = 0
        }
        
//        numberUserDefault.set(number, forKey: "number")
//        numberUserDefault.synchronize()
        if(self.minusBtn.tag == 1 || self.plusBtn.tag == 1) {
        self.delegate?.sendNumberOfRound(noOFRounds: number)
        }

    }

   
    @IBAction func addButton(_ sender: Any) {
        
        number += 1
        
        if number >= AddInterviewViewController().maximumNumberOfRounds {
            number = AddInterviewViewController().maximumNumberOfRounds
        }

//        numberUserDefault.set(number, forKey: "number")
//        numberUserDefault.synchronize()
        if(self.minusBtn.tag == 1 || self.plusBtn.tag == 1) {
            self.delegate?.sendNumberOfRound(noOFRounds: number)
        }
        
    }
   
   

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
