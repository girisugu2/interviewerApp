//
//  protocolClass.swift
//  iRecruit
//
//  Created by Giritharan Sugumar on 8/25/17.
//  Copyright © 2017 giritharan. All rights reserved.
//

import UIKit
protocol addInterviewDelegate {
    func round() -> String
}
class protocolClass: NSObject {

}
