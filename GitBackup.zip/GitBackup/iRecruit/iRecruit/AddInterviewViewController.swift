//
//  AddInterviewViewController.swift
//  interviewer
//
//  Created by Giritharan Sugumar on 7/20/17.
//  Copyright © 2017 giritharan. All rights reserved.
//

import UIKit

class AddInterviewViewController: UIViewController , UITableViewDelegate , UITableViewDataSource , RequiredTblCellDelegate, InterviewerDelegate {
    
    
    var hidePicker:Bool = false
    @IBOutlet weak var tblView: UITableView!
    var datePickerHidden = false
    var pickerHeight = 0
    var rounds = ["Enter Round1", "Enter Round2", "Enter Round3", "Enter Round4", "Enter Round5", "Enter Round6", "Enter Round7", "Enter Round8", "Enter Round9", "Enter Round10", "Enter Round11", "Enter Round12", "Enter Round13", "Enter Round14", "Enter Round15"]
    //   var labels = ["Role" , "People Required" , "Number Of Rounds" , "Experience Required" , "Notice Period", " Interview Date:"];
    var selectedDate:String = "Select the Date"
    var newDate:String = ""
    var addInterviewSections = ["Role","Candidates Required", "Number of Rounds", "Add Rounds", "Experience Required", "Picker", "Interview Date", "Date Picker"]
    var tableData = [1,2,0,1,1,1,1];
    
    var requiredFields = ["Candidates Required", "Number of Rounds"]
    
    let maximumNumberOfRounds = 15
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
      self.tblView.reloadData()
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return addInterviewSections.count
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0 {
            return 1
        } else if section == 1 {
            return 2
        } else if section == 2 {
            print("Table Data is \(tableData[2])")
            return self.tableData[2]
        } else if section == 3 {
            return 1
        } else if section == 4 {
            return 1
        } else if section == 5 {
            return 1
        } else if section == 6 {
            return 1
        }
            
        else {
            return 0
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 6 {
            
            if hidePicker == false {
                return CGFloat(pickerHeight)
            } else {
        
                return 0
            }
            
        } else {
            return 64
        }
    }
   
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "Role") as! RoleTableViewCell
            
            return cell
            
        }
    
        else if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Required") as! RequiredTableViewCell
            cell.delegate = self
            cell.plusBtn.tag = indexPath.row
            cell.minusBtn.tag = indexPath.row

            if indexPath.row == 0 {
                cell.requiredField.text = requiredFields[indexPath.row]
                
                
            } else if indexPath.row == 1 {
                cell.requiredField.text = requiredFields[indexPath.row]
                          }
            return cell
            
        }
            
        else if indexPath.section == 2 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddRounds") as! AddRoundsTableViewCell
        
            cell.roundText.placeholder = rounds[indexPath.row]
            cell.interviewerButton.setTitle("Add Interviewer", for: .normal)
            cell.interviewerButton.tag = indexPath.row
            
            
            
            return cell
            
        }
        else if indexPath.section == 3 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "Experience") as! ExperienceTableViewCell
            
            return cell
            
        }
        else if indexPath.section == 4 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "Picker") as! PickerTableViewCell
            
            return cell
            
        }

        
        else if indexPath.section == 5 {
            let interviewDateCell = tableView.dequeueReusableCell(withIdentifier: "InterviewDate") as! InterviewDateTableViewCell
            let tap = UITapGestureRecognizer(target: self, action: #selector(AddInterviewViewController.tapFunction))

            interviewDateCell.selectDate.isUserInteractionEnabled = true
              interviewDateCell.selectDate.addGestureRecognizer(tap)
            
            interviewDateCell.selectDate.text = selectedDate
            
            return interviewDateCell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DatePicker") as! DatePickerTableViewCell
            cell.datePicker.addTarget(self, action: #selector(changeDate), for: UIControlEvents.valueChanged)
            
            return cell
        }
        
    }
    
    var tableInterviewer = InterViewerViewController()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "interviewerCell" {
        let destinationVC = segue.destination as? InterViewerViewController
        let interviewerIndex = tableInterviewer.interviewerTable.indexPathForSelectedRow?.row
            print("InterviewerSelectedIndex is \(interviewerIndex)")
        }
    }
   
    
    func tapFunction(sender:UITapGestureRecognizer) {
        pickerHeight = 120
       hidePicker = false
        tblView.reloadData()
      
        print("tap working")
    }
    
    func changeDate(_ sender: UIDatePicker) {
        selectedDate = DateFormatter.localizedString(from: sender.date, dateStyle: DateFormatter.Style.short, timeStyle: DateFormatter.Style.short)
        selectedDate = "\(selectedDate)"
        tblView.reloadData()
        hidePicker = true
        
    }
    
    func sendNumberOfRound(noOFRounds: Int) {
        
        print(noOFRounds)
        
        self.tableData[2] = noOFRounds
        self.tblView.reloadData()
    }
    
    func sendInterviewer(Interviewer:String) {
        print("Int's are \(Interviewer)")
    }
    
}
