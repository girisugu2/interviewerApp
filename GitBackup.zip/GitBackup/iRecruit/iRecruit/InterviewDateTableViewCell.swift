//
//  InterviewDateTableViewCell.swift
//  
//
//  Created by Giritharan Sugumar on 8/8/17.
//
//

import UIKit

class InterviewDateTableViewCell: UITableViewCell {

    @IBOutlet weak var selectDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
